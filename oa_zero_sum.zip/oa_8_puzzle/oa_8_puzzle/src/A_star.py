from queue import PriorityQueue
from puzzle import Puzzle

from time import time

def Astar_search(initial_state):
    count=0
    explored=[]
    start_node=Puzzle(initial_state,None,None,0,True)
    q = PriorityQueue()
    q.put((start_node.evaluation_function,count,start_node))

    while not q.empty():
        node=q.get()
        node=node[2]
        explored.append(node.state)
        if node.goal_test():
            return node.find_solution()

        children=node.generate_child()
        for child in children:
            if child.state not in explored:
                count += 1
                q.put((child.evaluation_function,count,child))
    return

initial_state=[[1, 2, 3,
        8, 4, 0,
        7, 6, 5],

       [2, 8, 1,
        0, 4, 3,
        7, 6, 5],

       [2, 8, 1,
        4, 6, 3,
        0, 7, 5]]

goal_state=[1,2,3,
            8,0,4,
            7,6,5]

for i in range(0,3):
    Puzzle.num_of_instances=0
    t0=time()
    astar=Astar_search(initial_state[i])
    t1=time()-t0
    print('A* search:', astar)
    print('space:',Puzzle.num_of_instances)
    print('time:',t1)
    print()