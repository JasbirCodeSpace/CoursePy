import os

def filePath(fileName):
    return f"oa_water_jug/src/{fileName}"

def display():
    with open(filePath('code.py')) as f:
        print("===================Water Jug====================")
        for line in f:
            print(line, end='')